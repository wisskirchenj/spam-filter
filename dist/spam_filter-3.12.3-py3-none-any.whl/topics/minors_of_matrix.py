import scipy.special as sps

count = 0
for i in range(1, 6):
    count += i * i
print(count)